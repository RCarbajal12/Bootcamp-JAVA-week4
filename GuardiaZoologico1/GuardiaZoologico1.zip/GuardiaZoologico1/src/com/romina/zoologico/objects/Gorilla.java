package com.romina.zoologico.objects;

public class Gorilla extends Mamifero{
	
	public void throwSomething() {
		this.getEnergia();
		this.setEnergia(this.getEnergia()-5);
	}
	
	public void eatBananas() {
		this.setEnergia(getEnergia()+10);
	}
	
	public void climb() {
		this.setEnergia(getEnergia()-10);
	}

}
